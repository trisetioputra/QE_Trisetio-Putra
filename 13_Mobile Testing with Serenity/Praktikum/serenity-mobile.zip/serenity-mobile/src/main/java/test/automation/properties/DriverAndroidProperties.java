package test.automation.properties;

import java.util.HashMap;

public class DriverAndroidProperties {

    private HashMap<String, String> appiumProperties;

    public HashMap<String, String> getAppiumProperties() {
        return appiumProperties;
    }

    public void setAppiumProperties(HashMap<String, String> appiumProperties) {
        this.appiumProperties = appiumProperties;
    }
}
